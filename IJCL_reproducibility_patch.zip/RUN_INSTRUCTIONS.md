# Run instructions

1. Install R and the packages `data.table` and `ggplot2`.
2. Make sure `03_speaker_trial_analysis_units.csv` is available.
3. Open `OBC2_Inferential_Alignment_IJCL_MAJOR_REVISION_v5.R`.
4. Edit `BASE_DIR`/`INFILE` if necessary. If the file is not found, the script
   opens an interactive file chooser.
5. Run the script from top to bottom.
6. Confirm that the output directory contains:
   - `01_EB_parameters.csv`
   - `02_rate_diagnostics.csv`
   - `03_truth_sensitivity.csv`
   - `04_primary_EB_5000.csv`
   - `05_smoothing_sensitivity.csv`
   - `06_fixed_budget_allocation.csv`
   - `06b_fixed_budget_design_diagnostics.csv`
   - `07_source_matched_breadth.csv`
   - figure PNG files
   - `99_sessionInfo.txt`
7. For the fixed-budget results, check `delta_realized` and the four
   `exposure_*` fields before making across-N claims. The manuscript treats the
   rounded N = 100 and N = 500 imbalanced conditions as descriptive only.
