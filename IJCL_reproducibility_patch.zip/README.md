# Reproducibility package: inferential alignment in OBC 2.0

This folder documents and reproduces the analyses reported in the manuscript
*Balanced for what? Estimand-specific evidence structure in corpus design*.

## Required input

The main analysis starts from:

`03_speaker_trial_analysis_units.csv`

This derived table is created from the POS-tagged Old Bailey Corpus 2.0 files by
aggregating utterances to speaker-within-trial units. See
`DERIVED_VARIABLE_DICTIONARY.md` for the variables required by the current script.

## Software

The manuscript analyses were run in R 4.6.1 on Windows 11. The current scripts use:

- data.table 1.18.4
- ggplot2 4.0.3

## Random seed

The major-revision analysis uses:

`set.seed(20260925)`

## Run order

1. Obtain or recreate `03_speaker_trial_analysis_units.csv` from OBC 2.0.
2. Place it in the directory specified by `BASE_DIR`, or select it interactively if prompted.
3. Run `OBC2_Inferential_Alignment_IJCL_MAJOR_REVISION_v5.R`.
4. Inspect the generated CSV files before using the figures or manuscript summaries.
5. Use `MANUSCRIPT_OUTPUT_MAP.md` to identify which output supports each table/figure.

## Fixed-budget rounding diagnostic

The fixed-budget experiment uses N = 100, 200, 500, and 1,000 and nominal
delta = 0, .50, and .90. Integer cell counts mean that nominal delta is not
exact at N = 100 and 500 for the imbalanced conditions. The v5 script therefore
writes realised delta, the four cell counts, and the four cell exposures to the
fixed-budget output.

For inferential breadth comparisons in the manuscript:

- delta = 0 is exact at all four N values;
- at nominal delta = .90, N = 200 and N = 1,000 both realise delta = .900 and
  assign 6,250 tokens to each sparse cell;
- the rounded N = 100 and 500 imbalanced points are descriptive and are not used
  to quantify a pure breadth effect.

## Output location

By default, outputs are written to:

`~/Downloads/OBC_IJCL_MAJOR_REVISION_v5`

Edit `OUT_DIR` if another location is preferred.
