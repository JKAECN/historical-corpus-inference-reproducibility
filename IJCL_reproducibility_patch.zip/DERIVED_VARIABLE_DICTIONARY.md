# Derived-variable dictionary

The current major-revision analysis requires the following variables from
`03_speaker_trial_analysis_units.csv`.

| Variable | Definition |
|---|---|
| `proceeding` | OBC Proceeding/session identifier derived from the OBC2POS file name. |
| `trial_key` | Trial identifier within the Proceeding. |
| `speaker_trial_id` | Analysis-unit identifier combining the local speaker label with the trial context; it is not assumed to identify the same real-world person across trials. |
| `role` | Lower-case courtroom role. The primary experiment retains `witness` and `judge`. |
| `period2` | Two-period coding used in the primary experiment: `early` = 1720–1799; `late` = 1800–1879. |
| `tokens` | Total spoken-word exposure in the speaker-within-trial unit, summed from OBC utterance word counts. |
| `utterances` | Number of utterances contributing to the speaker-within-trial unit. |
| `modal_aux_n` | Count of tokens whose CLAWS7 POS tag begins with `VM`. |
| `first_person_n` | Count of first-person forms: I, me, my, mine, myself, we, us, our, ours, ourselves. |

Additional variables in the derived table may be retained for quality control but
are not required by the current two-probe simulations.

## Derived rate variables created by the current script

For each probe and Role × Period cell, the script creates:

- `*_raw_rate = count / tokens`
- `*_add_rate = (count + 0.5) / (tokens + 1)`
- `*_eb_rate = (count + alpha) / (tokens + beta)`

The Gamma–Poisson empirical-Bayes parameters `alpha` and `beta` are estimated
separately within feature × Role × Period cells by marginal likelihood.
